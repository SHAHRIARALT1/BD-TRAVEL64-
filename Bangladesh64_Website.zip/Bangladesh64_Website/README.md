# Bangladesh 64 — V1

A minimal, professional district travel tracker for all 64 districts of Bangladesh.

## Included
- Interactive Bangladesh district map
- Visited = light, not visited = dark
- 64-district database grouped by 8 divisions
- Search and filters
- District detail pages
- Visit date and personal notes
- Wishlist
- Progress counter
- LocalStorage persistence
- Installable PWA manifest

## Run
Serve this folder from a local web server (recommended) or deploy it to any static hosting service. The district boundary layer is loaded from the open Bangladesh GeoJSON dataset referenced in the app.

## Data attribution
District reference data and boundary data are based on the open `bangladesh-geojson` project by ifahimreza. Boundary data is CC BY 4.0; see the source project's license/metadata for attribution requirements.

Source: https://github.com/ifahimreza/bangladesh-geojson
