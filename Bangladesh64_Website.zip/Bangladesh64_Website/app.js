const GEOJSON_URL='https://raw.githubusercontent.com/ifahimreza/bangladesh-geojson/master/src/data/bangladesh.geojson';
let districts=[], state={}, selectedId=null, currentFilter='all', map=null, geoLayer=null;

const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function load(){districts=JSON.parse(document.getElementById('district-data').textContent||'[]');}
function initState(){
  const saved=JSON.parse(localStorage.getItem('bd64-state')||'{}');
  districts.forEach(d=>state[d.id]=saved[d.id]||{visited:false,visitedDate:'',notes:'',wishlist:false});
}
function persist(){localStorage.setItem('bd64-state',JSON.stringify(state));}
function visitedCount(){return districts.filter(d=>state[d.id].visited).length}
function updateStats(){
  const n=visitedCount(), p=Math.round(n/64*10000)/100;
  $('#visitedCount').textContent=n; $('#progressPct').textContent=p+'%'; $('#ringValue').textContent=p+'%';
  $('.progressRing').style.setProperty('--angle',(p/100*360)+'deg');
  const next=districts.find(d=>state[d.id].wishlist&&!state[d.id].visited)||districts.find(d=>!state[d.id].visited);
  $('#nextName').textContent=next?next.name:'All districts completed';
  $('#nextMeta').textContent=next?(state[next.id].wishlist?'Wishlist':'Not visited'):'Bangladesh Explorer — 64 / 64';
  renderMapStyles();
}
function showScreen(name){
  document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));
  $('#'+name).classList.add('active');
  document.querySelectorAll('.nav').forEach(x=>x.classList.toggle('active',x.dataset.screen===name));
  if(name==='districts') renderList();
  if(name==='wishlist') renderWishlist();
  if(name==='home' && map) setTimeout(()=>map.invalidateSize(),50);
}
function openDetail(id){
  selectedId=id; const d=districts.find(x=>x.id===id); const s=state[id];
  $('#detailNumber').textContent=String(d.id).padStart(2,'0'); $('#detailName').textContent=d.name; $('#detailDivision').textContent=d.division.toUpperCase()+' DIVISION';
  $('#visitedToggle').classList.toggle('on',s.visited); $('#visitDate').value=s.visitedDate||''; $('#notes').value=s.notes||''; $('#starBtn').classList.toggle('on',s.wishlist); $('#starBtn').textContent=s.wishlist?'★':'☆';
  showScreen('detail');
}
function renderList(){
  const q=$('#search').value.trim().toLowerCase();
  const filtered=districts.filter(d=>{
    const s=state[d.id]; const match=d.name.toLowerCase().includes(q)||d.division.toLowerCase().includes(q);
    return match && (currentFilter==='all'||(currentFilter==='visited'&&s.visited)||(currentFilter==='unvisited'&&!s.visited)||(currentFilter==='wishlist'&&s.wishlist));
  });
  $('#listCount').textContent=filtered.length;
  const groups={}; filtered.forEach(d=>(groups[d.division]??=[]).push(d));
  $('#districtList').innerHTML=Object.entries(groups).map(([div,arr])=>`<div class="division"><div class="divisionTitle">${esc(div)} DIVISION</div>${arr.map(d=>{
    const s=state[d.id]; return `<div class="districtRow" data-id="${d.id}"><div class="districtMain"><div class="check ${s.visited?'done':''}">${s.visited?'✓':''}</div><div><div class="districtName">${esc(d.name)}</div><div class="districtMeta">${s.visited?(s.visitedDate?'Visited '+s.visitedDate:'Visited'):'Not visited'}</div></div></div><div class="rowActions"><button class="miniStar ${s.wishlist?'on':''}" data-star="${d.id}">${s.wishlist?'★':'☆'}</button></div></div>`;
  }).join('')}</div>`).join('');
  document.querySelectorAll('.districtRow').forEach(r=>r.addEventListener('click',e=>{if(e.target.dataset.star)return;openDetail(+r.dataset.id)}));
  document.querySelectorAll('[data-star]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();const id=+b.dataset.star;state[id].wishlist=!state[id].wishlist;persist();updateStats();renderList()}));
}
function renderWishlist(){
  const items=districts.filter(d=>state[d.id].wishlist&&!state[d.id].visited);
  $('#wishlistList').innerHTML=items.length?items.map(d=>`<div class="districtRow" data-wid="${d.id}"><div class="districtMain"><div class="check">☆</div><div><div class="districtName">${esc(d.name)}</div><div class="districtMeta">${esc(d.division)} Division</div></div></div><span>›</span></div>`).join(''):`<div><b>No wishlist districts yet</b><br><small>Tap ☆ on any district to add it here.</small></div>`;
  document.querySelectorAll('[data-wid]').forEach(x=>x.addEventListener('click',()=>openDetail(+x.dataset.wid)));
}
function renderMapStyles(){
  if(!geoLayer)return;
  geoLayer.eachLayer(layer=>{
    const id=featureDistrictId(layer.feature);
    const d=districts.find(x=>x.id===id); const s=d&&state[d.id];
    layer.setStyle({fillColor:s&&s.visited?'#dfe7f0':'#263449',fillOpacity:1,color:'#f8fafc',weight:1});
  });
}
function norm(s){return String(s||'').toLowerCase().replace(/district|zilla|zila/g,'').replace(/[^a-z0-9]/g,'')}
const aliases={'coxsbazar':'Cox\'s Bazar','chattagram':'Chattogram','comilla':'Cumilla','khagrachari':'Khagrachhari','jessore':'Jashore','barisal':'Barishal','maulvibazar':'Moulvibazar','nawabganj':'Nawabganj','bogra':'Bogura','sirajganj':'Sirajganj'};
function featureDistrictId(f){
  const p=f.properties||{};
  const vals=Object.values(p).filter(v=>typeof v==='string');
  for(const v of vals){
    const n=norm(v); const alias=aliases[n]||v;
    const d=districts.find(x=>norm(x.name)===norm(alias));
    if(d)return d.id;
  }
  return null;
}
async function initMap(){
  map=L.map('map',{zoomControl:false,attributionControl:true,dragging:true,scrollWheelZoom:false,doubleClickZoom:true,touchZoom:true}).setView([23.75,90.35],6.2);
  L.control.zoom({position:'bottomright'}).addTo(map);
  try{
    const data=await fetch(GEOJSON_URL).then(r=>r.json());
    geoLayer=L.geoJSON(data,{style:{fillColor:'#263449',fillOpacity:1,color:'#f8fafc',weight:1},onEachFeature:(f,l)=>{
      const id=featureDistrictId(f); const d=districts.find(x=>x.id===id);
      l.on({mouseover:e=>e.target.setStyle({weight:2,fillColor:state[id]?.visited?'#c9d6e4':'#36465d'}),mouseout:e=>{if(geoLayer)renderMapStyles()},click:()=>{if(id)openDetail(id)}});
      if(d)l.bindTooltip(d.name,{sticky:true,direction:'center',className:'districtTip'});
    }}).addTo(map);
    map.fitBounds(geoLayer.getBounds(),{padding:[8,8]});
    renderMapStyles(); $('#mapStatus').textContent='64 district boundaries • Tap any district';
  }catch(e){
    $('#mapStatus').textContent='Map boundary data could not be loaded. District list remains available.';
  }
}
function bind(){
  document.querySelectorAll('.nav').forEach(b=>b.addEventListener('click',()=>showScreen(b.dataset.screen)));
  $('#backBtn').onclick=()=>showScreen('districts');
  $('#search').oninput=renderList;
  document.querySelectorAll('.filter').forEach(b=>b.onclick=()=>{currentFilter=b.dataset.filter;document.querySelectorAll('.filter').forEach(x=>x.classList.toggle('active',x===b));renderList()});
  $('#visitedToggle').onclick=()=>{$('#visitedToggle').classList.toggle('on')};
  $('#starBtn').onclick=()=>{state[selectedId].wishlist=!state[selectedId].wishlist;persist();$('#starBtn').classList.toggle('on',state[selectedId].wishlist);$('#starBtn').textContent=state[selectedId].wishlist?'★':'☆';updateStats()};
  $('#saveBtn').onclick=()=>{state[selectedId].visited=$('#visitedToggle').classList.contains('on');state[selectedId].visitedDate=$('#visitDate').value;state[selectedId].notes=$('#notes').value;persist();updateStats();showScreen('districts');};
  $('#nextBtn').onclick=()=>{const n=districts.find(d=>state[d.id].wishlist&&!state[d.id].visited)||districts.find(d=>!state[d.id].visited);if(n)openDetail(n.id)};
  $('#resetBtn').onclick=()=>{if(confirm('Reset all Bangladesh 64 progress, notes and wishlist?')){localStorage.removeItem('bd64-state');location.reload()}};
}
(async function(){
  districts=JSON.parse(document.getElementById('district-data').textContent);
  initState(); bind(); updateStats(); renderList(); await initMap();
})();
